module.exports = {
	extends: "universe/native",
};

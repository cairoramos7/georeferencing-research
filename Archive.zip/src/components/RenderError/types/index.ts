export interface RendeErrorI {
	error: string;
}

import RenderError from "./RenderError";

export default RenderError;

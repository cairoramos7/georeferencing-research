import RenderLatLng from "./RenderLatLng";

export default RenderLatLng;

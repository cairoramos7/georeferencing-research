import { CoordinatesInterface } from "@util/Types/Coodinates";

export interface RenderLatLngI {
	title: string;
	coords: CoordinatesInterface;
}
